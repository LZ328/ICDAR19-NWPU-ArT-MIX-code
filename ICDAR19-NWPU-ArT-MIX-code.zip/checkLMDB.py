import lmdb

env_db = lmdb.Environment('./DataDB/test')

txn = env_db.begin()

for key, value in txn.cursor():  
    print (key, value)  
  
env_db.close() 