require('torch')
require('nn')
require('paths')
require('nngraph')
require('image')
require('utilities')
require('DatasetLmdb')
require('MainModel_recog')
-- require('MainModel_recog')
require('hdf5')

-- Run a trained recognition model on images.

local cmd = torch.CmdLine()

-- Model options
cmd:option('-checkpoint','saved_model/checkpoint_epoch150000_6.2996.t7')
cmd:option('-valSetPath','DataDB_test/data.mdb','test data path')
cmd:option('-batch_size',18,'number of sequences to train on in parallel')
cmd:option('-token_dir','DataDB/token_dir','test data path')
cmd:option('-output_vis_dir', 'vis')
cmd:option('-seq_length',30,'number of timesteps to unroll for')
-- Misc
cmd:option('-gpu', 1)
cmd:option('-use_cudnn', 1)
cmd:option('-seed',123,'torch manual random number generator seed')
local opt = cmd:parse(arg)


function run_image(model, data, opt, dtype)
  -- Load, resize, and preprocess image
  local batchSize = opt.batch_size
  local nFrame = data.image:size(1)
  local losses = {}
  local captions = {}
  for i = 1, nFrame, batchSize do
    local actualBatchSize = math.min(batchSize, nFrame-i+1)
    local inputBatch_W = data.image_W:narrow(1,i,actualBatchSize)
    local inputBatch = data.image:narrow(1,i,actualBatchSize)
    local outputBatch = data.gt_labels:narrow(1,i,actualBatchSize)
    local lossBatch, captionBatch 
    local fb_time = timeit(function()
      lossBatch, captionBatch = model:forward_val(inputBatch, inputBatch_W, outputBatch)
    end)
  
    table.insert(losses,lossBatch)
    table.insert(captions,captionBatch)

  end

  local alllosses=torch.Tensor(losses)
  local allcaptions = nn.FlattenTable():forward(captions)
  local loss = torch.mean(alllosses)
  
  local output = {
          captions = allcaptions,
          loss = loss,
                }
  return output
end


-- Load the model, and cast to the right type
torch.setdefaulttensortype('torch.FloatTensor')
torch.manualSeed(opt.seed)
if opt.gpu >= 0 then
  -- cuda related includes and settings
  require 'cutorch'
  require 'cunn'
  require 'cudnn'
  cutorch.manualSeed(opt.seed)
  -- cutorch.setDevice(opt.gpu + 1) -- note +1 because lua is 1-indexed
end

local dtype = 'torch.CudaTensor'
local checkpoint = torch.load(opt.checkpoint)
local model = checkpoint.model

model:type(dtype)
model:evaluate()

-- load dataset
print('Loading datasets...')
local valSet = DatasetLmdb(opt.valSetPath, opt.batch_size)

-- train and test model
print('Start testing...')
-- loading data
local data = {}
data.image, data.gt_labels, data.image_W = valSet:allImages(opt)
for k, v in pairs(data) do
  data[k] = v:type(dtype)
end

-- get paths to all images we should be evaluating
local result = run_image(model, data, opt, dtype)
-- print(result)
print('validation loss:', result.loss)
correct = 0 
for ij = 1, data.image:size(1), 1 do

    local captions_gt = model.nets.recog_net:decodeSequence_org(data.gt_labels[{{ij},{}}])
    
    print((captions_gt[1]..','..result.captions[ij]))
    if (result.captions[ij]) == (captions_gt[1]) then
      --print((result.captions[ij]))
      --print((captions_gt[1]))
      print("true")
      correct = correct +1
    else
      --print((captions_gt[1]))
      --ChangePrint(result.captions[ij],'pred :')
      --ChangePrint(captions_gt[1],'gt is:')
      print("NO")
      
    end
end
acc = correct/data.image:size(1)
print('correct is :',correct)
print('acc is :',acc)
print('validation loss:', result.loss)
write_json(paths.concat(opt.output_vis_dir, 'results_IC15_BLSTM.json'), result)

